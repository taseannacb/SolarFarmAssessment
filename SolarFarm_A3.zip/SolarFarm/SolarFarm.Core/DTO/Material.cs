﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolarFarm.Core.DTO
{
    public enum Material
    {
        MultiCrySi,
        MonoCrysSi,
        AmorphouSi,
        CadmTellur,
        CoIndGalSe
    }
}
