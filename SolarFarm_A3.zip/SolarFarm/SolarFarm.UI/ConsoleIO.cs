﻿using System;
using SolarFarm.Core.Interfaces;
using SolarFarm.Core.DTO;

namespace SolarFarm.UI
{
    class ConsoleIO
    {
        public int GetInt(string prompt)
        {
            int result = -1;
            bool valid = false;
            while (!valid)
            {
                Console.Write($"{prompt}: ");
                if (!int.TryParse(Console.ReadLine(), out result))
                {
                    Error("NOT VALID, please enter a number only");
                }
                else
                {
                    valid = true;
                }
            }
            return result;
        }
        
        public void Display(string message)
        {
            Console.WriteLine(message);
        }
        
        public void Error(string message)
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Display(message);
            Console.ForegroundColor = ConsoleColor.Red;
        }
        
        public void Warn(string message)
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Display(message);
            Console.ForegroundColor = ConsoleColor.Yellow;
        }

        public void DisplayMenu()
        {
            Console.Clear();
            Display("Main Menu");
            Display("=========");
            Display("0. Exit");
            Display("1. Find Panels by Section");
            Display("2. Add a Panel");
            Display("3. Update a Panel");
            Display("4. Remove a Panel");
            Display("5. Materials List");
            Display("Select [0-4] ");
        }

        public DateTime ValiDATE(string input)
        {
            bool isValid = DateTime.TryParse(input, out DateTime date);
            while (!isValid)
            {
                Console.WriteLine("NOT VALID date format, please try YYYY");
                isValid = DateTime.TryParse(Console.ReadLine(), out date);
            }
            return date;
        }

        public int ValidInt(string input)
        {
            bool isValid = Int32.TryParse(input, out int output);
            while (!isValid)
            {
                Console.WriteLine("NOT VALID, please enter a number only");
                isValid = Int32.TryParse(Console.ReadLine(), out output);
            }
            return output;
        }
    }
}
