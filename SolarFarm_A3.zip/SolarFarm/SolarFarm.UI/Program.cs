﻿using SolarFarm.BLL;
using SolarFarm.Core.Interfaces;

namespace SolarFarm.UI
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleIO ui = new ConsoleIO();
            Controller execution = new Controller(ui);
            IPanelService service = PanelServiceFactory.GetPanelService();
            execution.Service = service;
            execution.Run();
        }
    }
}
